==============
Version 4.5.22
==============

Version 4.5.22 of mod_wsgi can be obtained from:

  https://codeload.github.com/GrahamDumpleton/mod_wsgi/tar.gz/4.5.22

Bugs Fixed
----------

* Change in version 4.5.21 caused Windows builds to break with undefined
  symbol ``wsgi_daemon_shutdown``.
